class RegistrationsController < Devise::RegistrationsController
  def new
    super
  end
  def show 
  end
end
