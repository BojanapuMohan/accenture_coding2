require 'will_paginate/array'
#require 'will_paginate/collection'