require 'test_helper'

class MultipleChoiceQuestionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
