require 'test_helper'

class DescriptiveQuestionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
